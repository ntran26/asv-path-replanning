"""The dynamic target: hull geometry, behaviour models, confinement (03a section 5).

Five behaviour models.  **Only `T-CV` is used in training** (decision D1); the
other four are evaluation-only, and the split matters — a policy trained against
reactive targets learns to rely on the other vessel co-operating, which is the
assumption COLREGs exists because no vessel can make.

| ID | Model | Used in |
|---|---|---|
| `T-CV` | Constant velocity, constant heading | Training and evaluation |
| `T-RE` | Compliant reactive — the COLREGs-VO rule, from the target's side | Evaluation only |
| `T-NC1` | Stands on when it is the give-way vessel | Evaluation only |
| `T-NC2` | Alters to **port** in a head-on | Evaluation only |
| `T-NC3` | Positionally non-compliant — holds the wrong side of the fairway | Evaluation only |
| `T-VS` | Constant heading, **varying speed** — one speed change on the approach | Evaluation only (Paper 2 layout set) |

**`T-NC3` is new in 03a section 5.3 and it is not optional.**  The head-on precedence
argument (02 section 3.2) is that Rule 9(a) channel-keeping satisfies Rule 14 *without*
an alteration.  If every head-on target is where 9(a) says it should be, the
policy is never asked to execute Rule 14 at all, and the head-on class is never
exercised as an avoidance problem.  `T-NC3` is the only case in the suite where
a head-on alteration is actually required, which makes it the case that decides
whether the precedence argument is testable.

**Confinement is class-conditional (03a section 5.2, 04a section 1.3).**  This supersedes
03 section 3's blanket "the target must respect the channel", which is unsatisfiable
for a crossing target: a vessel crossing a 4 m fairway at 90° runs into the far
wall.  The resolution is in the rulebook rather than the geometry — **Rule 9(d)
is specifically about vessels crossing a narrow channel**, and such a vessel is
not a channel user at all.  It is field-reproducible without modification,
because the corridor is a virtual map polygon inside a 10 m basin: a target can
physically cross a 4 m virtual corridor and continue into water the own ship
treats as non-navigable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import numpy as np

import constants as cfg

# Behaviour identifiers, as 03a section 5.3 names them.
T_CV = "T-CV"
T_RE = "T-RE"
T_NC1 = "T-NC1"
T_NC2 = "T-NC2"
T_NC3 = "T-NC3"
T_VS = "T-VS"

BEHAVIOURS = (T_CV, T_RE, T_NC1, T_NC2, T_NC3, T_VS)
TRAINING_BEHAVIOURS = (T_CV,)                      # D1
NON_COMPLIANT = (T_NC1, T_NC2, T_NC3)

# Which classes confine the target to the corridor (03a section 5.2).
CONFINED_CLASSES = ("head_on", "overtaking", "being_overtaken", "null")
UNCONFINED_CLASSES = ("crossing",)                 # Rule 9(d)

# Oriented hull, body frame at midships, x forward, y starboard (03a section 5.1).
# LOA 1.73 m, maximum breadth 0.50 m.  Own ship and target share this polygon --
# they are the same class of vessel, which is the premise on which S3 rejected
# the Rule 18 route in favour of Rule 9(b).
#
# TODO(03-5): replace with traced offsets if hull lines exist.  Centimetre
# accuracy matters only for the LiDAR return pattern, which feeds cluster-
# centroid bias in the tracker -- so it is a perception-fidelity question rather
# than a dynamics one.
HULL_OFFSETS = (
    (0.865, 0.000), (0.780, 0.130), (0.600, 0.215), (0.250, 0.250),
    (-0.550, 0.250), (-0.865, 0.230), (-0.865, -0.230), (-0.550, -0.250),
    (0.250, -0.250), (0.600, -0.215), (0.780, -0.130),
)


def hull_polygon(x: float, y: float, heading_deg: float,
                 offsets: Sequence = HULL_OFFSETS) -> List[Tuple[float, float]]:
    """`HULL_OFFSETS` placed in the world at a pose.

    Headings are compass-style: 0 is +y, clockwise positive.  Forward is
    `(sin psi, cos psi)` and starboard is `(cos psi, -sin psi)`.
    """
    a = math.radians(float(heading_deg))
    sin_a, cos_a = math.sin(a), math.cos(a)
    return [(float(x) + fwd * sin_a + lat * cos_a,
             float(y) + fwd * cos_a - lat * sin_a)
            for fwd, lat in offsets]


# ---------------------------------------------------------------------------
# The target
# ---------------------------------------------------------------------------
@dataclass
class Target:
    """One COLREGs target vessel, with a behaviour model.

    Replaces the circle-plus-heading placeholder.  An oriented polygon is
    required for aspect-angle computation, for ship-domain metrics, and for a
    LiDAR return pattern that looks like a vessel rather than like a buoy --
    all three feed N1.
    """

    x: float
    y: float
    heading: float                       # deg, compass
    speed: float                         # m/s
    behaviour: str = T_CV
    encounter_class: str = "null"
    confined: bool = True
    corridor: object = None              # set for confined targets
    # `T-VS`: (t_change_s, final_speed_mps, accel_mps2) -- holds `speed` until
    # t_change, then ramps to final_speed at accel.  None for every other model.
    speed_profile: Optional[Tuple[float, float, float]] = None
    # Field-feasible scenarios (Paper 2 layout set): (xmin, xmax, ymin, ymax) the
    # hull must stay inside -- the basin less a wall margin.  A target about to
    # leave it stops for the rest of the episode, as the boat in the field would
    # be stopped short of the wall.  None everywhere else.
    stop_box: Optional[Tuple[float, float, float, float]] = None
    _stopped: bool = field(default=False, repr=False)

    # Latched on first engagement, for the reactive and non-compliant models.
    _reacted: bool = field(default=False, repr=False)
    _t: float = field(default=0.0, repr=False)
    # A34: set by `clamp_to_corridor` when the fairway edge stops a target that
    # has manoeuvred; the manoeuvring models then hold the edge heading.
    _edge_hold: bool = field(default=False, repr=False)
    _course0: Optional[float] = field(default=None, repr=False)
    _plan_course: Optional[float] = field(default=None, repr=False)
    _next_plan: float = field(default=0.0, repr=False)
    _side_latched: bool = field(default=False, repr=False)

    # ------------------------------------------------------------------
    @property
    def heading_deg(self) -> float:
        return float(self.heading)

    @property
    def velocity(self) -> np.ndarray:
        a = math.radians(self.heading)
        return np.array([self.speed * math.sin(a), self.speed * math.cos(a)])

    def hull(self) -> List[Tuple[float, float]]:
        return hull_polygon(self.x, self.y, self.heading)

    # ------------------------------------------------------------------
    def step(self, dt: float, *, own=None) -> None:
        """Advance one control step, applying the behaviour model.

        `own` is the own-ship state the reactive and non-compliant models need.
        Training targets (`T-CV`) ignore it entirely, which is why the training
        environment never has to supply it.
        """
        self._t += float(dt)
        if self._stopped:
            return
        if self.speed_profile is not None:
            self._vary_speed(dt)
        if self.behaviour != T_CV and own is not None:
            self._react(dt, own)

        v = self.velocity
        nx, ny = self.x + float(v[0]) * dt, self.y + float(v[1]) * dt
        if self.stop_box is not None:
            x0, x1, y0, y1 = self.stop_box
            xs, ys = zip(*hull_polygon(nx, ny, self.heading))
            if min(xs) < x0 or max(xs) > x1 or min(ys) < y0 or max(ys) > y1:
                self.speed, self._stopped = 0.0, True
                return
        self.x, self.y = nx, ny

    # ------------------------------------------------------------------
    def _react(self, dt: float, own) -> None:
        """Behaviour models other than constant velocity.

        `T-NC3` is deliberately absent: it is a *positional* violation, fixed at
        spawn by placing the target on the wrong side of the fairway, and it
        holds course from there.  Encoding it as a manoeuvre would make it a
        behavioural violation and it would stop testing what it exists to test.
        """
        if self.behaviour in (T_NC1, T_NC3, T_VS):
            return                        # holds course; T-VS varies speed only
        if self.behaviour == T_RE:
            self._react_vo(dt, own)
            return

        import cpa_cri as cc
        p_os = (float(own["x"]), float(own["y"]))
        p_ts = (self.x, self.y)
        dcpa, tcpa = cc.cpa(p_os, own["velocity"], p_ts, self.velocity)

        engaged = 0.0 < tcpa < cfg.T_ENGAGE and dcpa < cfg.KAPPA_ENG * 2.0 * cfg.DOMAIN_LATERAL
        if not engaged:
            return

        if self.behaviour == T_NC2:
            # Alters to PORT in a head-on -- the classic wrong-way violation,
            # and the reason 04a section 11.4 requires passing-side correctness to be
            # reported conditioned on target compliance.  Scored against the own
            # ship it would otherwise read as a policy failure.
            if self.encounter_class == "head_on" and not self._edge_hold:
                self._turn(-TURN_RATE_DPS * dt)
                self._reacted = True
            return

    def _vary_speed(self, dt: float) -> None:
        """`T-VS`: hold the spawn speed until `t_change`, then ramp toward the
        final speed at `accel` -- a vessel that slows or speeds up on the
        approach without altering course.  Evaluation only (Paper 2 layout set)."""
        t_change, v_final, accel = (float(v) for v in self.speed_profile)
        if self._t < t_change:
            return
        step = float(accel) * float(dt)
        gap = v_final - self.speed
        self.speed = v_final if abs(gap) <= step else self.speed + math.copysign(step, gap)

    def _react_vo(self, dt: float, own) -> None:
        """`T-RE`: the COLREGs-VO comparator's rule, applied from the target's side
        (03a section 5.3 asks for one implementation, A34).

        Every decision interval the target classifies the encounter by the
        open-water roles, with the own ship as *its* traffic, and takes the
        course `colregs_vo.select_velocity` picks at its own speed: altering to
        starboard and passing astern when it gives way, standing on under Rule 17
        when it does not, and returning to its course once the pass is clear.
        It turns at `TURN_RATE_DPS`.  Two departures from the comparator's
        settings, both because this is the *other* vessel behaving well: the side
        rule is judged on the encounter and held until the target stops closing
        (per candidate, a turn to port that opens the pass counts as compliant,
        A35), and the hard clearance is `TARGET_RE_HARD_GAP_M`, not the
        comparator's 0.20 m (with it the target cut back 0.6 m ahead of the own
        ship).  Static panels are not its concern, and a
        confined target that meets the fairway edge stops
        manoeuvring (`_edge_hold`) and keeps the edge heading the clamp gave it --
        the placeholder's continuous turn fought `clamp_to_corridor` and
        saw-toothed along the edge (F99), and so did turning back to its course.
        """
        import constant_temp as ct
        from classical import colregs_vo as kvo
        if self._course0 is None:
            self._course0 = float(self.heading)
        if self._plan_course is None or self._t + 1e-9 >= self._next_plan:
            self._next_plan = self._t + cfg.UPDATE_RATE
            p = np.array([self.x, self.y])
            h = math.radians(self.heading)
            p_own = np.array([float(own["x"]), float(own["y"])])
            v_own = np.asarray(own["velocity"], dtype=float)
            h_own = math.radians(float(own["heading"]))
            cls = kvo.classify(p, h, self.speed, p_own, v_own, h_own)
            other = kvo.Target(p_own, v_own, h_own, cls)
            # The side rule holds from the moment the encounter is live until
            # the target stops closing -- Rule 8(d)/16: keep clear until finally
            # past, not until the pass merely looks wide enough.
            closing, live = kvo.encounter_state(other, p, self.velocity)
            self._side_latched = closing and (live or self._side_latched)
            prev = None if self._plan_course is None else math.radians(self._plan_course)
            choice = kvo.select_velocity(p, h, self.speed, math.radians(self._course0), self.speed,
                                         [other], prev_course=prev, speed_fractions=(1.0,),
                                         side_live=self._side_latched,
                                         hard_gap=ct.TARGET_RE_HARD_GAP_M)
            self._plan_course = math.degrees(choice.course) % 360.0
            if abs(_wrap(self._plan_course - self._course0)) > 1.0:
                self._reacted = True
        if self._edge_hold:
            return                        # the fairway edge ended the manoeuvre
        delta = _wrap(self._plan_course - self.heading)
        self._turn(max(-TURN_RATE_DPS * dt, min(TURN_RATE_DPS * dt, delta)))

    def _turn(self, delta_deg: float) -> None:
        self.heading = (self.heading + float(delta_deg)) % 360.0


def _wrap(deg: float) -> float:
    return (float(deg) + 180.0) % 360.0 - 180.0


# Reactive-target turn rate.  A model vessel's sustained rate of turn, not a
# free parameter: it should come from 05's identified turning circle at the same
# time `R_REF` does.
TURN_RATE_DPS = 8.0                      # deg/s, TODO(05)


# ---------------------------------------------------------------------------
# Confinement
# ---------------------------------------------------------------------------
def is_confined(encounter_class: str) -> bool:
    """Does this class keep the target inside the corridor? (03a section 5.2)"""
    return str(encounter_class) not in UNCONFINED_CLASSES


def confinement_violation(target: Target, corridor,
                          polygon=None) -> Optional[float]:
    """How far a confined target has strayed outside its corridor, metres.

    `None` when the target is unconfined (crossing, under Rule 9(d)) or inside.
    Used by acceptance test T7, which asserts the rule holds both ways round:
    crossing targets *must* leave and every other class *must not*.
    """
    if not target.confined or corridor is None:
        return None
    import boundary_raycast as br
    # Pass the polygon when available.  `Corridor.polygon()` rebuilds the
    # outline from 500 stations on every call, and testing the 11 hull vertices
    # one call at a time multiplied that: together they were 40 % of every
    # environment step, the single largest cost in the simulator.
    poly = corridor.polygon() if polygon is None else polygon
    hull = np.asarray(target.hull(), dtype=float)
    inside = np.asarray(br.points_in_polygon(hull[:, 0], hull[:, 1], poly), dtype=bool)
    if inside.all():
        return None
    outside = hull[~inside]
    dist = br.points_boundary_distance(outside[:, 0], outside[:, 1], poly)
    return float(np.max(dist))


def clamp_to_corridor(target: Target, corridor, polygon=None) -> None:
    """Keep a confined target inside the channel.

    Confined targets run constant-velocity down a channel that may bend, so
    without this a long episode walks them into the wall.  Rather than steer
    them -- which would make them reactive and break D1 -- the heading is nudged
    back toward the local channel tangent, which is what a vessel keeping the
    fairway does anyway.
    """
    if not target.confined or corridor is None:
        return
    if confinement_violation(target, corridor, polygon) is None:
        return

    # Nearest centreline station, then adopt its tangent direction.
    violation = confinement_violation(target, corridor, polygon)
    if target._reacted:
        target._edge_hold = True         # A34: the manoeuvre has used the room
    deltas = corridor.centre - np.array([target.x, target.y])
    index = int(np.argmin(np.einsum("ij,ij->i", deltas, deltas)))
    tangent = corridor.tangent(index)
    along = math.degrees(math.atan2(float(tangent[0]), float(tangent[1])))
    # A target running *against* the channel keeps its own sense of direction.
    if abs(((target.heading - along + 180.0) % 360.0) - 180.0) > 90.0:
        along = (along + 180.0) % 360.0
    target.heading = along
    # A21: nudge, do not teleport.  The target moves inward only as far as the
    # breach (plus a hull-breadth of slack for the heading change), keeping its
    # lateral station.  Snapping to the centreline put overtakers onto the own
    # ship's track (F60).
    toward_centre = deltas[index]                        # centre station minus target
    normal = np.array([-float(tangent[1]), float(tangent[0])])
    lateral = float(np.dot(toward_centre, normal))
    shift = min(abs(lateral), float(violation or 0.0) + 0.1)
    target.x += float(normal[0]) * math.copysign(shift, lateral)
    target.y += float(normal[1]) * math.copysign(shift, lateral)
