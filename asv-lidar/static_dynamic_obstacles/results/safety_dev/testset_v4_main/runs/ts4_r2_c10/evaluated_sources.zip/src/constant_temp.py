"""Classical comparator settings — staging file, to be merged into `constants.py`.

**Why this is separate (decision, 2026-09-23).** Every constant in this project
lives in `constants.py`, and these belong there too. They are staged here until
the baseline-v2 campaign finishes, for one mechanical reason: the frozen
formulation's digest is computed over *every* upper-case name in `constants.py`
(`src/baseline_config.py`), so adding or tuning a value there would change the
digest, fail the pre-run check and halt the campaign mid-flight.

Nothing in training reads this file. It holds the parameters of the classical
comparators (04a section 5):

* **LOS-PID** — the shared path follower and its controller gains;
* **LOS-PID + DWA** — dynamic-window sampling, horizons and clearance scoring;
* **Encounter-specific VO** — velocity-obstacle horizons, candidate sampling,
  the ship-domain scaling and the cost weights.

**Values are ported unchanged** from `src/classical/` as of 2026-09-23, except
`CLASSICAL_KVO_W_CHANGE`, tuned that day (C3a).

*Tuning outcome (C3a, `results/classical_tuning/`).* Both comparators were
fitted on the development set by coordinate descent over a declared grid, scored
by goal rate − 2 × collision rate — the rule RL checkpoints are selected by — and
the winners were then **confirmed on all 120 development episodes**:

* **COLREGs-VO**: +0.525 → **+0.575**, from `W_CHANGE` 0.3 → 0.8. Kept.
* **LOS-PID + DWA**: the 60-episode search preferred a 14 s target horizon and a
  1.0 m clearance cap (+0.700 → +0.850), but on all 120 episodes that scored
  **+0.650, exactly the defaults**. The gain was noise in a 60-episode subset.
  **Defaults kept**, and the episode is worth reporting: it is the reason the
  search is validated rather than trusted.

**Still to do (C3-C6, after the campaign):**
1. tune on the **development set** against the same score the RL checkpoints use
   (goal rate − 2 × collision rate), with the search reported;
2. record the tuned values and their digest with every comparator result, so a
   table says what the baselines were;
3. merge this file into `constants.py`, excluding these names from the
   formulation digest (they are not part of the RL formulation);
4. build COLREGs-VO (Kuwata), which does not exist yet (B8).

Derived quantities (`HALF_L`, `SUBSTEPS`, `DELAY_STEPS`, `U_PER_RPM`) stay in
`src/classical/common.py`: they follow from the hull and the identified plant,
and are not free parameters.
"""
import math

import numpy as np

import constants as cfg

# ---------------------------------------------------------------------------
# Shared: actuation limits and the LOS path follower (src/classical/common.py)
# ---------------------------------------------------------------------------
CLASSICAL_MAX_RUDDER_DEG = 40.0          # deg, command limit
CLASSICAL_LOS_LOOKAHEAD_M = 2.5          # m, look-ahead distance
CLASSICAL_MAX_SIDESLIP_DEG = 20.0        # deg, sideslip compensation cap

# Heading PID, on the LOS course error.
CLASSICAL_PID_KP = 1.0 / 35.0            # rudder units per deg
CLASSICAL_PID_KD = 1.0 / 18.0            # per deg/s of measured yaw rate
CLASSICAL_PID_KI = 1.0 / 600.0           # per deg.s
CLASSICAL_PID_I_GATE_DEG = 10.0          # integral acts only inside this error
CLASSICAL_PID_I_LIMIT = 0.15             # rudder units

# Yaw-rate and speed loops.
CLASSICAL_YAW_RATE_GAIN_DPS = 10.4       # deg/s at full rudder, identified plant
CLASSICAL_YAW_RATE_KP = 0.08             # rudder units per deg/s of error
CLASSICAL_SPEED_KP_RPM = 6.0             # rpm-units per m/s of speed error

# Prediction and perception memory.
CLASSICAL_PRED_DT = 0.125                # s, rollout step
CLASSICAL_SCAN_MEMORY_FRAMES = 4         # scans retained for static structure
CLASSICAL_TRACK_EXCLUSION_M = 1.8        # returns this close to a track are the target's

# ---------------------------------------------------------------------------
# LOS-PID + DWA (src/classical/los_dwa.py)
# ---------------------------------------------------------------------------
CLASSICAL_DWA_TRAVEL_M = 5.5             # static obstacles judged over this track (10 s at cruise)
CLASSICAL_DWA_TARGET_HORIZON_S = 10.0    # tracked targets judged over this time
CLASSICAL_DWA_MAX_HORIZON_S = 16.0       # rollout length for the slowest candidate
CLASSICAL_DWA_YAW_RATES_DPS = tuple(np.linspace(-9.0, 9.0, 9))   # inside the 10.4 deg/s turn
CLASSICAL_DWA_SPEED_FRACTIONS = (1.0, 0.5, 0.0)                  # of U_NOM; 0 = propulsion floor
CLASSICAL_DWA_COMMIT_S = (3.0, 6.0)      # how long a candidate is held
CLASSICAL_DWA_LOS_SPEED_FRACTIONS = (1.0, 0.5)
CLASSICAL_DWA_SAFE_GAP_M = 0.20          # hull-to-hull, beyond the hull margin
CLASSICAL_DWA_BOUNDARY_GAP_M = 0.05      # the map polygon is exact, the scan is not
CLASSICAL_DWA_DIST_CAP_M = 1.5           # clearance beyond this earns nothing more
CLASSICAL_DWA_PATH_SCALE_M = 2.0         # mean cross-track error scoring zero
CLASSICAL_DWA_ENGAGE_RANGE_M = 9.0       # target range at which avoidance engages

# ---------------------------------------------------------------------------
# Encounter-specific VO (src/classical/encounter_vo.py)
# ---------------------------------------------------------------------------
CLASSICAL_VO_COURSE_OFFSETS_DEG = tuple(np.arange(-90.0, 90.01, 5.0))   # about the present heading
CLASSICAL_VO_SPEED_FRACTIONS = (1.0, 0.75, 0.5, 0.25, 0.0)
CLASSICAL_VO_TAU_S = 20.0                # horizon for tracked targets
CLASSICAL_VO_TAU_STATIC_S = 10.0         # and for scan points and the map polygon
CLASSICAL_VO_DT = 0.25                   # s, cone sampling step
CLASSICAL_VO_HARD_GAP_M = 0.20           # hull-to-hull clearance treated as a hard limit
CLASSICAL_VO_STATIC_GAP_M = 0.15
CLASSICAL_VO_BOUNDARY_GAP_M = 0.05
CLASSICAL_VO_SIDE_FREE_DCPA_M = 2.0 * cfg.DOMAIN_LATERAL   # 2.5 m: the pass is clear either side
CLASSICAL_VO_STAND_ON_RELEASE_S = 12.0   # 17(a)(ii): act when the give-way vessel has not
CLASSICAL_VO_TURN_LAG_S = 1.0            # assumed response lag of the other vessel
CLASSICAL_VO_TURN_RATE_DPS = 6.0         # assumed turn rate when projecting a response
CLASSICAL_VO_SPEED_TAU_DOWN_S = 60.0     # speed-change time constants
CLASSICAL_VO_SPEED_TAU_UP_S = 20.0

# Ship-domain scaling per encounter class, as (fore, aft, lateral) multipliers:
# crossing stretches ahead so a candidate keeps the target further off the own
# bow (a clear pass astern); head-on and overtaking widen abeam, where those
# passes happen.
CLASSICAL_VO_DOMAIN_SCALE = {
    "head_on": (1.0, 1.0, 1.2),
    "crossing": (1.5, 1.0, 1.0),
    "overtaking": (1.0, 1.0, 1.2),
    "being_overtaken": (1.0, 1.0, 1.0),
    "none": (1.0, 1.0, 1.0),
}

# Cost weights over the candidate (course, speed) set.
CLASSICAL_VO_W_COURSE = 1.0              # per pi rad from the preferred course
CLASSICAL_VO_W_SPEED = 0.5               # per cruise speed below preferred
CLASSICAL_VO_W_CHANGE = 0.3              # per pi rad from the previous course
CLASSICAL_VO_W_DOMAIN = 3.0              # per unit of ship-domain penetration
CLASSICAL_VO_STATIC_SOFT_M = 0.6         # static cost reaches zero here
CLASSICAL_VO_W_STATIC = 1.0              # at the hard gap

# ---------------------------------------------------------------------------
# COLREGs-VO, Kuwata et al. 2014 (src/classical/colregs_vo.py)
# ---------------------------------------------------------------------------
# The published method's own rule model: open-water roles, and the give-way
# constraint that the relative velocity stays to starboard of the bearing line.
CLASSICAL_KVO_HEAD_ON_HALF_DEG = 22.5    # deg, reciprocal sector (Rule 14)
CLASSICAL_KVO_OVERTAKING_DEG = 112.5     # deg, the overtaking sector (Rule 13)
CLASSICAL_KVO_COURSE_OFFSETS_DEG = tuple(np.arange(-90.0, 90.01, 5.0))
CLASSICAL_KVO_SPEED_FRACTIONS = (1.0, 0.75, 0.5, 0.25, 0.0)
CLASSICAL_KVO_TAU_S = 20.0               # horizon for tracked targets
CLASSICAL_KVO_TAU_STATIC_S = 10.0        # and for scan points and the map polygon
CLASSICAL_KVO_DT = 0.25                  # s, sampling step along the horizon
CLASSICAL_KVO_HARD_GAP_M = 0.20          # hull-to-hull clearance treated as a hard limit
CLASSICAL_KVO_STATIC_GAP_M = 0.15
# The reactive target (`targets.T_RE`, A34) runs the COLREGs-VO rule from the
# other vessel's side, but keeps clear by more than the comparator's 0.20 m: a
# compliant vessel stays out of the own ship's lateral domain, so hull-to-hull
# DOMAIN_LATERAL less one beam (1.25 - 0.50 m; side by side the centres are then
# DOMAIN_LATERAL apart).  With 0.20 m a reactive overtaker cut back 0.6 m
# (centres) ahead of the own ship.  Not a comparator parameter: outside
# configs/comparators_v1.json.  TODO(A34): confirm with the basin traffic model.
TARGET_RE_HARD_GAP_M = cfg.DOMAIN_LATERAL - 0.50
# The varying-speed target (`targets.T_VS`, Paper 2 layout set, 2026-09-27): one
# speed change on the approach, at a random fraction of the drawn TCPA, to a
# slower or faster speed (even odds), ramped at a model vessel's acceleration.
# Evaluation only.  TODO(05): the ramp should come from the identified surge
# response, as TURN_RATE_DPS should from the turning circle.
TARGET_VS_CHANGE_FRAC = (0.25, 0.75)      # of the drawn TCPA
TARGET_VS_SLOW_FACTOR = (0.50, 0.80)      # final / initial speed
TARGET_VS_FAST_FACTOR = (1.25, 1.50)
TARGET_VS_ACCEL_MPS2 = 0.05
# A target whose nominal track passes within this of a static panel (hull to
# panel) is redrawn: targets are not steered around panels, so one sailing
# through a panel would be unphysical.
TARGET_PANEL_CLEARANCE_M = 0.30
# Field feasibility of the Paper 2 layout set (2026-09-27): every target scenario
# must be one a second model vessel can actually sail in the 10 x 25 m basin.
# The target is assumed Bluefin-class: it cruises at 1.116 m/s at 12 rpm-units
# (the July logs, `U_REF_LOG_MEDIAN`) and holds steerage down to ~0.2 m/s.
# TODO(field): confirm against the vessel used as the target.
FIELD_TARGET_SPEED_RANGE = (0.20, 1.10)   # m/s, the VAR twin's final speed included
FIELD_WALL_MARGIN_M = 0.50                # target hull to basin wall, at spawn and when it stops
FIELD_MAX_TURN_DEG = 1.0                  # a straight track: the operator holds one heading
FIELD_POST_CPA_S = 3.0                    # the encounter is over before the target reaches a wall
CLASSICAL_KVO_BOUNDARY_GAP_M = 0.05
CLASSICAL_KVO_SIDE_FREE_DCPA_M = 2.0 * cfg.DOMAIN_LATERAL   # wider passes are unconstrained
CLASSICAL_KVO_STAND_ON_RELEASE_S = 12.0  # Rule 17: hold while the preferred velocity stays clear
CLASSICAL_KVO_TURN_RATE_DPS = 6.0        # the turn rate the candidate sweep assumes
CLASSICAL_KVO_W_COURSE = 1.0             # per pi rad from the preferred course
CLASSICAL_KVO_W_SPEED = 0.5              # per cruise speed below preferred
# Tuned on the development set, 2026-09-23 (C3a): 0.3 -> 0.8, confirmed on all
# 120 episodes (+0.525 -> +0.575).  A stronger change penalty stops the
# candidate course dithering between equally cheap options frame to frame.
CLASSICAL_KVO_W_CHANGE = 0.8             # per pi rad from the previous course
# Static returns get the same soft margin the other comparators use: with the
# hard gap alone the controller skims obstacles and scored 0.30-0.50 on episodes
# with no encounter at all, which would have made Kuwata look weak for a reason
# that has nothing to do with COLREGs.
CLASSICAL_KVO_STATIC_SOFT_M = 0.6
CLASSICAL_KVO_W_STATIC = 1.0

# Radians, for the code that wants them.
CLASSICAL_MAX_RUDDER_RAD = math.radians(CLASSICAL_MAX_RUDDER_DEG)
CLASSICAL_MAX_SIDESLIP_RAD = math.radians(CLASSICAL_MAX_SIDESLIP_DEG)
