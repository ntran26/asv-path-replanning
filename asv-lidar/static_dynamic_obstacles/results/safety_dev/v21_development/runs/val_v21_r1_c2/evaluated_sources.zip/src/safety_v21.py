"""Experimental V21: V16 with a braking fallback where V16 finds no escape.

V16 (through V6) admits braking candidates and braking recoveries only when a
target track is within `ENGAGE_RANGE_M` (7 m), the restriction V2's iteration 6
introduced against stopping near walls.  With no target that close, V16 checks
turning and cruising plans only, and when none passes it returns SAC's command
unchecked (`no escape`).  On the baseline-v3 validation set (V21 phase, 2026-10-25)
every plan that passes V16's own checker at those decisions brakes, either at once or
in its recovery, and V16 hands SAC the helm instead.

At a decision V16 leaves unchecked (by default `no escape` only), V21 scores the same
primitive bank with the braking candidates and braking recoveries included, from the
snapshot and pre-command actuator history V16 already used, with V16's own rollout
and evaluation.  If some plan passes, it takes V6's selection rule (the passing
candidate closest to SAC within the room floor) and commits that plan exactly as V6's
`brake` branch does; otherwise V16's decision stands.  Every other decision is
V16's, unchanged.  This relaxes no check: the fallback issues only plans that pass
the inherited checker.

`braking_fallback=False` reproduces V16.  `fallback_branches` names the V16 branches
the fallback may replace (``("no escape", "last certificate")`` also replaces the
bounded uncertified continuation).

`SafetyFilterV21E` adds the permanent emergency stop (planning_records/
SAFETY_ESTOP_PROTOCOL.md) on top; a braking-fallback plan counts as checked there.
"""
from __future__ import annotations

import copy

import numpy as np

import safety_estop as estop
import safety_v2 as v2
import safety_v3 as v3
import safety_v4 as v4
import safety_v16 as v16

BRAKING_FALLBACK = True
FALLBACK_BRANCHES = ("no escape",)
LABEL = "braking fallback"


class SafetyFilterV21(v16.SafetyFilterV16):
    def __init__(self, *, braking_fallback=None, fallback_branches=None, **v16_options):
        super().__init__(**v16_options)
        self.braking_fallback = BRAKING_FALLBACK if braking_fallback is None else bool(braking_fallback)
        branches = FALLBACK_BRANCHES if fallback_branches is None else tuple(fallback_branches)
        if not set(branches) <= {"no escape", "last certificate"}:
            raise ValueError("fallback_branches must name unchecked V16 branches")
        self.fallback_branches = branches

    def _filter(self, env, action):
        out, changed = super()._filter(env, action)
        why = self.last.get("why", "idle")
        self.last["v21_braking_fallback"] = self.braking_fallback
        if self.braking_fallback and why in self.fallback_branches:
            result = self._fallback(env, action, why)
            if result is not None:
                return result
            self.last["v21_fallback_found"] = False
        return out, changed

    def _fallback(self, env, action, v16_why):
        snap = getattr(self, "_observer_snapshot", None)
        before = getattr(self, "_observer_actuators", None)
        if snap is None or before is None:
            return None
        action = np.clip(np.asarray(action, dtype=float).reshape(2), -1.0, 1.0)
        rows = ([tuple(action)] + [(r, t) for r in v2.RUDDERS for t in v2.THROTTLES]
                + [tuple(self._rejoin(snap))] + [(r, np.nan) for r in v2.BRAKE_RUDDERS])
        candidates = np.asarray(rows, dtype=float)
        templates = v4.recovery_templates([(r, np.nan if t is v2.BRAKE else t) for r, t in v2.RECOVERY])
        count, nrec = len(candidates), len(templates)
        bank = v4.sequence_bank(candidates, templates)
        first, clear = self._evaluate(snap, self._rollout(snap, copy.deepcopy(before), bank))
        first, clear = first.reshape(count, nrec), clear.reshape(count, nrec)
        ok = np.isinf(first)
        safe = ok.any(axis=1)
        if not safe.any():
            return None
        margin = np.where(ok, clear, -np.inf).max(axis=1)
        best_rec = np.argmax(np.where(ok, clear, -np.inf), axis=1)
        # V6's selection: the passing candidate closest to SAC within the room floor.
        pool = np.flatnonzero(safe)
        floor = min(v2.TRIGGER_MARGIN_M, float(margin[pool].max()) - v2.ROOM_SLACK_M)
        pool = pool[margin[pool] >= floor]
        throttle = np.where(np.isnan(candidates[pool, 1]), -1.5, candidates[pool, 1])
        score = (candidates[pool, 0] - action[0]) ** 2 + v2.W_THROTTLE * (throttle - action[1]) ** 2
        chosen = int(pool[np.argmin(score)])
        rec = int(best_rec[chosen])

        # Replace V16's command as V6 commits a checked plan; the actuator history
        # restarts from before V16 issued SAC's rudder.
        self.actuators = copy.deepcopy(before)
        self.mode, self.plan = "recovery", bank[chosen * nrec + rec].copy()
        self.uncertified_steps = 0
        out = candidates[chosen].copy()
        brake = bool(np.isnan(out[1]))
        env._v2_brake = brake
        if brake:
            out[1] = -1.0
        out = out.astype(np.float32)
        self.actuators.issue(env, float(out[0]))
        changed = brake or not np.allclose(out, action)
        self.last.update({
            "mode": "recovery", "why": LABEL, "v21_replaced": v16_why, "v21_fallback_found": True,
            "changed": bool(changed), "brake": brake, "chosen": out.tolist(),
            "checked_clearance": float(margin[chosen]), "selection_floor": float(floor),
            "v21_plan_brakes": bool(np.isnan(self.plan[:, 1]).any()),
            "v21_safe_candidates": int(safe.sum()), "plan_steps": len(self.plan),
            "uncertified_steps": 0, "recovery_steps": self.recovery_steps,
        })
        return out, bool(changed)


class _CheckedLabel(SafetyFilterV21):
    """Presents a braking-fallback plan to the stop detector as the checked `brake` branch."""

    def _filter(self, env, action):
        out, changed = super()._filter(env, action)
        if self.last.get("why") == LABEL:
            self.last["why"] = "brake"
            self.last["v21_relabelled"] = True
        return out, changed


class SafetyFilterV21E(estop.EmergencyStopMixin, _CheckedLabel):
    """V21 with the permanent emergency stop; a braking-fallback plan counts as checked."""

    def _filter(self, env, action):
        out, changed = super()._filter(env, action)
        if self.last.pop("v21_relabelled", False) and self.last.get("why") == "brake":
            self.last["why"] = LABEL
        return out, changed
