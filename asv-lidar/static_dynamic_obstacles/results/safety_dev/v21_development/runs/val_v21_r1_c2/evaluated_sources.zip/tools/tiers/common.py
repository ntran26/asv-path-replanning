"""Shared machinery for the tiered formulation tests (PROJECT_STATE F60).

    Tier 0  scripted policies     minutes   does the reward point the right way?
    Tier 1  replay a saved model  ~15 min   what does a trained policy do under today's code?
    Tier 2  short fine-tune       ~1 h      does the policy move the way the change intends?
    Tier 3  full run from scratch ~6 h      only once Tiers 0-2 read clean

Every tier replays **fixed** scenario sets from the development namespace, so a
before/after comparison changes the code and nothing else.  Episodes run in a
process pool, one environment per process.
"""
from __future__ import annotations

import math
import os
import sys
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

import constants as cfg  # noqa: E402
import curriculum  # noqa: E402
import scenario as scn  # noqa: E402
import train_formulation as tf  # noqa: E402

RESULTS = ROOT / "results" / "tiers"
COLREGS_PARTS = ("port", "bow", "side", "hold", "r8")
# The dense reward terms (`reward.terms.DENSE_TERMS`): the seven task terms and the
# COLREGs group.
REWARD_TERMS = ("pf", "prog", "exist", "smooth", "obs", "bnd", "dom", "col")
HEAD_ON_WIDTHS = (5.0, 6.0, 7.0, 8.0, 10.0)


# ---------------------------------------------------------------------------
# Fixed scenario sets
# ---------------------------------------------------------------------------
def development_set(per_class: int, classes=tf.EVAL_CLASSES) -> List:
    """The formulation run's evaluation set, optionally restricted by class."""
    return [b for b in tf.development_set(per_class) if b.encounter_class in classes]


def head_on_width_set(per_width: int = 20) -> List:
    """The C14 set: head-on at 5, 6, 7, 8 and 10 m, 20 each (F54)."""
    gen = scn.ScenarioGenerator(stage=5, seed_namespace="development")
    out = []
    for w in HEAD_ON_WIDTHS:
        j = found = 0
        while found < per_width and j < 20 * per_width:
            b = gen.sample(scn.seed_for("development", 300_000 + int(w * 10) * 1000 + j),
                           encounter_class="head_on", width=w)
            j += 1
            if b is not None:
                out.append(b)
                found += 1
    return out


# ---------------------------------------------------------------------------
# Policies
# ---------------------------------------------------------------------------
def _wrap180(a: float) -> float:
    return (float(a) + 180.0) % 360.0 - 180.0


def follower_action(env) -> np.ndarray:
    """LOS path follower at cruise; ignores targets."""
    rudder = float(np.clip(env.lookahead_course_error / 25.0 + 0.4 * env.cross_track_error, -1.0, 1.0))
    return np.array([rudder, 0.0], dtype=np.float32)


def colregs_action(env, sense_sign: int, alteration_deg: float = 30.0) -> np.ndarray:
    """Follower, plus a committed alteration while a give-way encounter is engaged.

    `sense_sign=+1` turns the way the reward says is compliant; `-1` the
    opposite way.  The alteration is a heading target relative to the heading at
    engagement, so it is one large alteration (Rule 8(b)), held until the
    encounter clears, then the follower returns to the path.
    """
    for ctx in env.encounter_contexts.values():
        if (sense_sign < 0 and ctx.engaged and str(ctx.cls) == "being_overtaken"
                and ctx.tcpa > 0.0):
            # Stand-on vessel: compliance is holding, so the "wrong" policy
            # leaves the role with the same 30 deg alteration, to starboard.
            want = float(ctx.psi_engage) + alteration_deg
            rudder = float(np.clip(_wrap180(want - env.asv_h) / 20.0, -1.0, 1.0))
            return np.array([rudder, 0.0], dtype=np.float32)
        if ctx.engaged and ctx.gives_way and ctx.compliant_turn_sense != 0 and ctx.tcpa > 0.0:
            s = sense_sign * int(ctx.compliant_turn_sense)
            want = float(ctx.psi_engage) + s * alteration_deg
            rudder = float(np.clip(_wrap180(want - env.asv_h) / 20.0, -1.0, 1.0))
            return np.array([rudder, 0.0], dtype=np.float32)
    return follower_action(env)


# The classical comparators (B8) and the prototype's reference controller: onboard
# controllers that read the environment's perception, one instance per episode.
CONTROLLERS = ("los_dwa", "colregs_vo", "encounter_vo", "reference")


def make_controller(policy: str):
    if policy == "los_dwa":
        from classical.los_dwa import LosDwaController
        return LosDwaController()
    if policy == "colregs_vo":
        from classical.colregs_vo import ColregsVOController
        return ColregsVOController()
    if policy == "encounter_vo":
        from classical.encounter_vo import EncounterVOController
        return EncounterVOController()
    if policy == "reference":
        from reference_controller import ReferenceController
        return ReferenceController()
    return None


# ---------------------------------------------------------------------------
# One episode, with everything any tier reads
# ---------------------------------------------------------------------------
def run_episode(env, built, seed: int, policy: str, model=None, obstacles: Optional[int] = None,
                keep_traj: bool = False) -> Dict:
    if obstacles is not None:
        env.forced_num_obs = int(obstacles)
    obs, _ = env.reset(seed=seed, options={"generated": built})
    total, col, speeds, steps, ctes = 0.0, 0.0, [], 0, []
    frames = Counter()
    integrals = Counter()
    # Reward scale audit (Table R7, decision S19, 2026-10-24): the weighted episode
    # integral of every reward term and the steps on which each term was non-zero,
    # read from the per-step breakdown the environment already reports.
    reward_int, reward_active = Counter(), Counter()
    first_engaged_cls, port_sense_frames, engaged_frames = None, 0, 0
    stops, stop_steps, r_path_max = [], [], 0.0
    min_range = float("inf")
    last_events = 0
    # Paper 2's per-episode metrics (src/metrics.py, the same definitions) plus the
    # target-ship ones, added 2026-10-08 for the paper's results table.
    import metrics as pm
    rudder_cmd: List[float] = []
    min_obs_clear = min_bnd_clear = min_tgt_clear = float("inf")
    dom_max, dom_steps, viol_steps = 0.0, 0, 0
    # true trajectories for the per-rule COLREGs checks (first target only; one per episode)
    own_xy, own_h, own_u, tgt_xy, tgt_h, engaged_now = [], [], [], [], [], []

    def record_state(engaged_flag: bool) -> None:
        own_xy.append((env.asv_x, env.asv_y))
        own_h.append(float(env.asv_h))
        own_u.append(float(env.speed_mps))
        if env.targets:
            tgt_xy.append((env.targets[0].x, env.targets[0].y))
            tgt_h.append(float(env.targets[0].heading))
        engaged_now.append(engaged_flag)

    record_state(False)
    actor = tf.EpisodeActor(model) if policy == "model" else None
    controller = make_controller(policy)
    while True:
        if policy == "model":
            action = actor(obs)
        elif controller is not None:
            action = controller.action(env, obs)
        elif policy == "follower":
            action = follower_action(env)
        elif policy == "compliant":
            action = colregs_action(env, +1)
        elif policy == "wrong_way":
            action = colregs_action(env, -1)
        else:
            raise ValueError(policy)
        obs, reward, term, trunc, info = env.step(action)
        steps += 1
        total += float(reward)
        col += float(info["reward/weighted/col"])
        for name in REWARD_TERMS:
            value = float(info.get(f"reward/weighted/{name}", 0.0))
            reward_int[name] += value
            reward_active[name] += int(value != 0.0)
        reward_int["terminal"] += float(info.get("reward/terminal", 0.0))
        reward_int["intervention"] += float(info.get("reward/intervention", 0.0))
        speeds.append(float(info["speed_mps"]))
        ctes.append(float(env.cross_track_error))
        r_path_max = max(r_path_max, abs(float(info["r_path_radps"])))
        violating = False
        for part in COLREGS_PARTS:
            value = float(info.get(f"colregs/v_{part}", 0.0))
            frames[part] += int(value > 0.0)
            integrals[part] += value
            violating = violating or value > 0.0
        viol_steps += int(violating)
        rudder_cmd.append(float(np.clip(action[0], -1.0, 1.0)))
        hull = env.hull_polygon()
        if env.obstacles:
            min_obs_clear = min(min_obs_clear, pm.min_obstacle_clearance(hull, env.obstacles))
        min_bnd_clear = min(min_bnd_clear, float(env._hull_boundary_distance(hull)))
        for t in env.targets:
            min_tgt_clear = min(min_tgt_clear, pm.polygon_distance(hull, t.hull()))
        intrusion = float(getattr(env.last_reward_state, "dom_intrusion", 0.0) or 0.0)
        dom_max = max(dom_max, intrusion)
        dom_steps += int(intrusion > 0.0)
        any_engaged = False
        for ctx in env.encounter_contexts.values():
            any_engaged = any_engaged or bool(ctx.engaged)
            if ctx.engaged and ctx.tcpa > 0.0:
                engaged_frames += 1
                first_engaged_cls = first_engaged_cls or str(ctx.cls)
                port_sense_frames += int(ctx.compliant_turn_sense < 0 and str(ctx.cls) != "overtaking")
        record_state(any_engaged)
        if int(info["estop/events"]) > last_events:
            last_events = int(info["estop/events"])
            stops.append(env.estop.events[-1].reason)
            stop_steps.append(steps)
        for t in env.targets:
            min_range = min(min_range, math.hypot(t.x - env.asv_x, t.y - env.asv_y))
        if term or trunc:
            break
    ct = float(getattr(built, "ct_deg", 0.0))
    outcome = (f"collision:{info['collision_kind']}" if info["collided"] else
               "goal" if info["reached_goal"] else "timeout")
    # The true trajectories, for the per-rule COLREGs checks computed offline
    # (tools/diagnostics/colregs_compliance.py); kept only when a caller asks (`_job`).
    traj = {"own_x": np.array([p[0] for p in own_xy], np.float32),
            "own_y": np.array([p[1] for p in own_xy], np.float32),
            "own_h": np.array(own_h, np.float32), "own_u": np.array(own_u, np.float32),
            "engaged": np.array(engaged_now, bool),
            "path": np.asarray(env.path.points, np.float32)}
    if tgt_xy and len(tgt_xy) == len(own_xy):
        traj.update(tgt_x=np.array([p[0] for p in tgt_xy], np.float32),
                    tgt_y=np.array([p[1] for p in tgt_xy], np.float32), tgt_h=np.array(tgt_h, np.float32))
    row = {
        "policy": policy, "class": built.encounter_class, "width": float(built.nominal_width),
        "dcpa_m": float(getattr(built, "dcpa_m", 0.0)), "ct_deg": ct,
        "crossing_side": ("port" if ct < 180.0 else "starboard") if built.encounter_class == "crossing" else "",
        "dcpa_below_floor": getattr(built, "dcpa_below_floor", None),
        "crossing_escapable": getattr(built, "crossing_escapable", None),
        "outcome": outcome, "collided": bool(info["collided"]),
        "collided_target": info["collision_kind"] == "target",
        "steps": steps, "return": total, "colregs_integral": col,
        **{f"frames_v_{p}": frames[p] for p in COLREGS_PARTS},
        **{f"integral_v_{p}": integrals[p] for p in COLREGS_PARTS},
        "mean_speed": float(np.mean(speeds)), "max_speed": float(np.max(speeds)),
        "min_target_range": min_range,
        "rms_cte": float(np.sqrt(np.mean(np.square(ctes)))),
        "estops": len(stops), "estop_reasons": " | ".join(stops),
        "safety_v2_steps": int(getattr(env, "safety_v2_steps", 0)),
        "safety_v2_brake_steps": int(getattr(env, "safety_v2_brake_steps", 0)),
        "estop_then_target_collision": bool(stops) and info["collision_kind"] == "target",
        "first_engaged_cls": first_engaged_cls or "never",
        "engaged_frames": engaged_frames,
        "p_port_sense": port_sense_frames / max(engaged_frames, 1),
        "ever_port_sense_non_overtaking": port_sense_frames > 0,
        "r_path_max": r_path_max,
        # --- the paper's results table (Paper 2 definitions, src/metrics.py) ----------
        "completion_time_s": steps * float(cfg.UPDATE_RATE),
        "min_speed": float(np.min(speeds)),
        "path_length_m": pm._polyline_length(env.asv_path),
        "path_efficiency": (pm._polyline_length(env.asv_path) / float(env.path.length)
                            if float(env.path.length) > 1e-6 else float("nan")),
        "min_obstacle_clearance": min_obs_clear if math.isfinite(min_obs_clear) else float("nan"),
        "min_boundary_clearance": min_bnd_clear if math.isfinite(min_bnd_clear) else float("nan"),
        "mean_abs_rudder_rate": (float(np.mean(np.abs(np.diff(np.asarray(rudder_cmd) * pm.MAX_RUD_ANGLE))))
                                 / float(cfg.UPDATE_RATE) if len(rudder_cmd) > 1 else 0.0),
        "rudder_saturation_fraction": float(np.mean(np.abs(np.asarray(rudder_cmd)) >= pm.SATURATION_THRESHOLD)),
        "control_effort": float(np.sum(np.square(rudder_cmd)) * float(cfg.UPDATE_RATE)),
        # target ship (true positions): hull-to-hull clearance, ship-domain intrusion
        # (deepest, as a fraction of the domain radius, and time inside), time with a
        # COLREGs penalty term active
        "min_target_clearance": min_tgt_clear if math.isfinite(min_tgt_clear) else float("nan"),
        "domain_intrusion_max": dom_max,
        "domain_time_s": dom_steps * float(cfg.UPDATE_RATE),
        "colregs_violation_time_s": viol_steps * float(cfg.UPDATE_RATE),
        # reward scale audit (Table R7): weighted episode integral per term, the terminal
        # and safety-layer rewards, and the steps on which each term was non-zero
        **{f"reward_int_{n}": reward_int[n] for n in (*REWARD_TERMS, "terminal", "intervention")},
        **{f"reward_active_{n}": reward_active[n] for n in REWARD_TERMS},
    }
    if keep_traj:
        row["_traj"] = traj
    return row


# ---------------------------------------------------------------------------
# Process pool
# ---------------------------------------------------------------------------
_WORKER = {}


def _init_worker(model_path: Optional[str], overrides: Optional[Dict] = None) -> None:
    import torch
    torch.set_num_threads(1)
    for name, value in (overrides or {}).items():
        setattr(cfg, name, value)
    curriculum.apply_stage(tf.PROPULSION_STAGE)
    from env import ASVLidarEnv
    _WORKER["env"] = ASVLidarEnv(render_mode=None)
    if overrides and "EMERGENCY_STOP_ENABLED" in overrides:
        # The constructor default is bound at import; apply the switch directly.
        _WORKER["env"].estop_enabled = bool(overrides["EMERGENCY_STOP_ENABLED"])
    if overrides and "LOW_SPEED_START_FRAC" in overrides:
        # F70: force episodes to start slow or at rest (a constructor argument too).
        _WORKER["env"].low_speed_start_frac = float(overrides["LOW_SPEED_START_FRAC"])
    _WORKER["model"] = None
    if model_path:
        _WORKER["model"] = load_model(model_path)
        # A run that trained with run-time switches (fix 1) is evaluated with them.
        import json
        from pathlib import Path as _P
        run_cfg = _P(model_path).parent / "config.json"
        if run_cfg.exists():
            for name, value in (json.loads(run_cfg.read_text()).get("constant_overrides") or {}).items():
                setattr(cfg, name, value)


def load_model(model_path):
    """Load a saved policy with the learner its run recorded (any of the five)."""
    import json
    from pathlib import Path as _P
    algo = "ppo"
    config = _P(model_path).parent / "config.json"
    if config.exists():
        algo = json.loads(config.read_text()).get("algo", "ppo")
    return tf.ALGORITHMS[algo].load(str(model_path), device="cpu")


def _job(args) -> Dict:
    built, seed, policy, obstacles, extra = args
    extra = dict(extra)
    keep = bool(extra.pop("_keep_traj", False))
    row = run_episode(_WORKER["env"], built, seed, policy, _WORKER["model"], obstacles, keep_traj=keep)
    row.update(extra)
    return row


def run_pool(jobs: List, model_path: Optional[str] = None, processes: int = None,
             overrides: Optional[Dict] = None) -> List[Dict]:
    """jobs: (built, seed, policy, obstacles, extra-columns) tuples.  `overrides`
    sets `constants` attributes in every worker, for A/B switches."""
    processes = processes or max(1, min(10, (os.cpu_count() or 2) - 2))
    curriculum.apply_stage(tf.PROPULSION_STAGE)
    with ProcessPoolExecutor(max_workers=processes, initializer=_init_worker,
                             initargs=(str(model_path) if model_path else None, overrides)) as pool:
        return list(pool.map(_job, jobs, chunksize=1))


def width_bin(width: float) -> str:
    for edge, label in ((5.5, "5"), (6.5, "6"), (7.5, "7"), (9.0, "8")):
        if width <= edge:
            return label
    return "10"
